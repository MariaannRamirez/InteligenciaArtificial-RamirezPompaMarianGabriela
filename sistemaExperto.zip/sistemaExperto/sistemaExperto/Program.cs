﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace sistemaExperto
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Sistema Experto Difuso para Gimnasio";

            do
            {
                Console.Clear();
                MostrarCabecera();

                double experiencia = LeerEntradaValidada("Nivel de experiencia (1-10): ", 1, 10);
                double objetivo = LeerEntradaValidada("Objetivo (1=Perder grasa, 5=Mantener, 10=Ganar músculo): ", 1, 10);
                double tiempo = LeerEntradaValidada("Tiempo disponible en minutos (30-120): ", 30, 120);

                var recomendacion = ObtenerRecomendacion(experiencia, objetivo, tiempo);

                MostrarRecomendacion(recomendacion.rutina, recomendacion.intensidad);

            } while (PreguntarRepetir());
        }
        static void MostrarCabecera()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("══════════════════════════════════════");
            Console.WriteLine(" SISTEMA EXPERTO PARA RUTINAS DE GIMNASIO ");
            Console.WriteLine("══════════════════════════════════════");
            Console.ResetColor();
            Console.WriteLine();
        }

        static (string rutina, string intensidad) ObtenerRecomendacion(double experiencia, double objetivo, double tiempo)
        {
            var fuzzyEngine = new FuzzyEngine();
            ConfigurarVariables(fuzzyEngine);
            ConfigurarReglas(fuzzyEngine);

            fuzzyEngine.SetInput("Experiencia", experiencia);
            fuzzyEngine.SetInput("Objetivo", objetivo);
            fuzzyEngine.SetInput("Tiempo", tiempo);

            fuzzyEngine.Process();

            return (
                fuzzyEngine.GetOutput("Rutina"),
                fuzzyEngine.GetOutput("Intensidad")
            );
        }

        static double LeerEntradaValidada(string mensaje, double min, double max)
        {
            double valor;
            while (true)
            {
                Console.Write(mensaje);
                if (double.TryParse(Console.ReadLine(), out valor) && valor >= min && valor <= max)
                    return valor;

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Error: Ingrese un número entre {min} y {max}");
                Console.ResetColor();
            }
        }

        static void MostrarRecomendacion(string rutina, string intensidad)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n════════════ RECOMENDACIÓN ════════════");
            Console.ResetColor();

            Console.WriteLine($"\n• Tipo de rutina: {rutina.ToUpper()}");
            Console.WriteLine($"• Intensidad: {intensidad.ToUpper()}");

        }

        static bool PreguntarRepetir()
        {
            Console.Write("\n¿Desea otra recomendación? (s/n): ");
            return Console.ReadLine().Trim().ToLower() == "s";
        }


        static void ConfigurarVariables(FuzzyEngine engine)
        {
            engine.AddInputVariable("Experiencia", 0, 10);
            engine.AddFuzzySet("Experiencia", "Principiante", new TriangularFunction(0, 0, 4));
            engine.AddFuzzySet("Experiencia", "Intermedio", new TriangularFunction(2, 5, 8));
            engine.AddFuzzySet("Experiencia", "Avanzado", new TriangularFunction(6, 10, 10));

            engine.AddInputVariable("Objetivo", 1, 10);
            engine.AddFuzzySet("Objetivo", "PerderGrasa", new TriangularFunction(1, 1, 5));
            engine.AddFuzzySet("Objetivo", "Mantener", new TriangularFunction(3, 5, 7));
            engine.AddFuzzySet("Objetivo", "GanarMusculo", new TriangularFunction(5, 10, 10));

            engine.AddInputVariable("Tiempo", 30, 120);
            engine.AddFuzzySet("Tiempo", "Corto", new TriangularFunction(30, 30, 60));
            engine.AddFuzzySet("Tiempo", "Moderado", new TriangularFunction(45, 75, 105));
            engine.AddFuzzySet("Tiempo", "Largo", new TriangularFunction(90, 120, 120));

            engine.AddOutputVariable("Rutina", new List<string> { "Cardio", "Mixta", "Fuerza" });
            engine.AddOutputVariable("Intensidad", new List<string> { "Baja", "Media", "Alta" });
        }

        static void ConfigurarReglas(FuzzyEngine engine)
        {
            engine.AddRule("SI Experiencia ES Principiante Y Objetivo ES PerderGrasa Y Tiempo ES Corto ENTONCES Rutina ES Cardio Y Intensidad ES Baja");
            engine.AddRule("SI Experiencia ES Intermedio Y Objetivo ES GanarMusculo Y Tiempo ES Largo ENTONCES Rutina ES Fuerza Y Intensidad ES Alta");
            // ... (Agrega el resto de las reglas aquí)
        }
    }

    // ==================== IMPLEMENTACIÓN DE LÓGICA DIFUSA ====================
    public class TriangularFunction
    {
        private double a, b, c;

        public TriangularFunction(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public double Evaluate(double x)
        {
            if (x <= a || x >= c) return 0;
            if (x == b) return 1;
            if (x < b) return (x - a) / (b - a);
            return (c - x) / (c - b);
        }
    }

    public class FuzzyEngine
    {
        private Dictionary<string, Dictionary<string, TriangularFunction>> inputSets = new Dictionary<string, Dictionary<string, TriangularFunction>>();
        private Dictionary<string, List<string>> outputSets = new Dictionary<string, List<string>>();
        private List<string> rules = new List<string>();
        private Dictionary<string, double> inputs = new Dictionary<string, double>();
        private Dictionary<string, Dictionary<string, double>> outputValues = new Dictionary<string, Dictionary<string, double>>();

        public void AddInputVariable(string name, double min, double max)
        {
            if (!inputSets.ContainsKey(name))
                inputSets[name] = new Dictionary<string, TriangularFunction>();
        }

        public void AddFuzzySet(string variable, string setName, TriangularFunction function)
        {
            if (inputSets.ContainsKey(variable))
                inputSets[variable][setName] = function;
        }

        public void AddOutputVariable(string name, List<string> terms)
        {
            outputSets[name] = terms;
            outputValues[name] = new Dictionary<string, double>();
            foreach (var term in terms)
                outputValues[name][term] = 0;
        }

        public void SetInput(string variable, double value)
        {
            inputs[variable] = value;
        }

        public void AddRule(string rule)
        {
            rules.Add(rule);
        }

        public void Process()
        {
            // Reset outputs
            foreach (var output in outputValues)
                foreach (var term in output.Value.Keys.ToList())
                    output.Value[term] = 0;

            // Evaluate each rule
            foreach (var rule in rules)
            {
                var parts = rule.Split(new[] { "ENTONCES" }, StringSplitOptions.RemoveEmptyEntries);
                var conditions = parts[0].Replace("SI", "").Trim().Split(new[] { "Y" }, StringSplitOptions.RemoveEmptyEntries);
                var conclusions = parts[1].Trim().Split(new[] { "Y" }, StringSplitOptions.RemoveEmptyEntries);

                double ruleStrength = 1;

                // Evaluate conditions (AND)
                foreach (var cond in conditions)
                {
                    var condParts = cond.Trim().Split(new[] { "ES" }, StringSplitOptions.RemoveEmptyEntries);
                    var varName = condParts[0].Trim();
                    var setName = condParts[1].Trim();

                    if (inputSets.ContainsKey(varName) && inputSets[varName].ContainsKey(setName))
                    {
                        double membership = inputSets[varName][setName].Evaluate(inputs[varName]);
                        ruleStrength = Math.Min(ruleStrength, membership);
                    }
                }

                // Apply to conclusions
                foreach (var concl in conclusions)
                {
                    var conclParts = concl.Trim().Split(new[] { "ES" }, StringSplitOptions.RemoveEmptyEntries);
                    var outputVar = conclParts[0].Trim();
                    var outputTerm = conclParts[1].Trim();

                    if (outputValues.ContainsKey(outputVar) && outputValues[outputVar].ContainsKey(outputTerm))
                    {
                        outputValues[outputVar][outputTerm] = Math.Max(outputValues[outputVar][outputTerm], ruleStrength);
                    }
                }
            }
        }

        public string GetOutput(string variable)
        {
            if (!outputValues.ContainsKey(variable)) return "";

            // Simple defuzzification: Select term with highest membership
            var maxTerm = outputValues[variable].OrderByDescending(kv => kv.Value).FirstOrDefault();
            return maxTerm.Key;
        }
    }
}