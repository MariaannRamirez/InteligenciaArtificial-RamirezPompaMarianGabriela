﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _8puzzle
{
    class Program
    {
        public class Nodo
        {
            public string Estado { get; set; }
            public Nodo Padre { get; set; }
            public int Costo { get; set; }  // Costo acumulado (g(n))
            public int Heuristica { get; set; }  // Valor heurístico (h(n))

            public Nodo(string estado, Nodo padre = null, int costo = 0, int heuristica = 0)
            {
                Estado = estado;
                Padre = padre;
                Costo = costo;
                Heuristica = heuristica;
            }

            public int CostoTotal => Costo + Heuristica;
        }

        public class Puzzle8
        {
            public static string EstadoInicial = "587063421";
            public static string EstadoFinal = "123456780";

            public static void Main(string[] args)
            {
                Console.WriteLine("=== Métodos de Búsqueda ===");
                Console.WriteLine("1. Búsqueda en Anchura");
                Console.WriteLine("2. Búsqueda en Profundidad");
                Console.WriteLine("3. Búsqueda A* (Heurística)");
                Console.WriteLine("4. Búsqueda Primero el Mejor (Heurística)");
                Console.Write("Seleccione una opción: ");
                int opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        BusquedaPrimeroEnAnchura();
                        break;
                    case 2:
                        BusquedaPrimeroEnProfundidad();
                        break;
                    case 3:
                        BusquedaAEstrella();
                        break;
                    case 4:
                        BusquedaPrimeroElMejor();
                        break;
                    default:
                        Console.WriteLine("Opción no válida.");
                        break;
                }
            }

            // === Búsquedas No Informadas ===
            public static void BusquedaPrimeroEnAnchura()
            {
                Queue<Nodo> frontera = new Queue<Nodo>();
                HashSet<string> explorados = new HashSet<string>();
                frontera.Enqueue(new Nodo(EstadoInicial));

                while (frontera.Count > 0)
                {
                    Nodo nodo = frontera.Dequeue();
                    if (nodo.Estado == EstadoFinal)
                    {
                        ImprimirSolucion(nodo);
                        return;
                    }
                    explorados.Add(nodo.Estado);
                    foreach (string sucesor in GenerarSucesores(nodo.Estado))
                    {
                        if (!explorados.Contains(sucesor) && !frontera.Any(n => n.Estado == sucesor))
                        {
                            frontera.Enqueue(new Nodo(sucesor, nodo, nodo.Costo + 1));
                        }
                    }
                }
            }

            public static void BusquedaPrimeroEnProfundidad()
            {
                Stack<Nodo> frontera = new Stack<Nodo>();
                HashSet<string> explorados = new HashSet<string>();
                frontera.Push(new Nodo(EstadoInicial));

                while (frontera.Count > 0)
                {
                    Nodo nodo = frontera.Pop();
                    if (nodo.Estado == EstadoFinal)
                    {
                        ImprimirSolucion(nodo);
                        return;
                    }
                    explorados.Add(nodo.Estado);
                    foreach (string sucesor in GenerarSucesores(nodo.Estado))
                    {
                        if (!explorados.Contains(sucesor) && !frontera.Any(n => n.Estado == sucesor))
                        {
                            frontera.Push(new Nodo(sucesor, nodo, nodo.Costo + 1));
                        }
                    }
                }
            }

            // === Búsquedas Heurísticas ===
            public static void BusquedaAEstrella()
            {
                var frontera = new SortedSet<Nodo>(new ComparadorAEstrella());
                HashSet<string> explorados = new HashSet<string>();
                frontera.Add(new Nodo(EstadoInicial, null, 0, CalcularHeuristica(EstadoInicial)));

                while (frontera.Count > 0)
                {
                    Nodo nodo = frontera.First();
                    frontera.Remove(nodo);

                    if (nodo.Estado == EstadoFinal)
                    {
                        ImprimirSolucion(nodo);
                        return;
                    }
                    explorados.Add(nodo.Estado);
                    foreach (string sucesor in GenerarSucesores(nodo.Estado))
                    {
                        int nuevoCosto = nodo.Costo + 1;
                        int heuristica = CalcularHeuristica(sucesor);
                        if (!explorados.Contains(sucesor) && !frontera.Any(n => n.Estado == sucesor))
                        {
                            frontera.Add(new Nodo(sucesor, nodo, nuevoCosto, heuristica));
                        }
                    }
                }
            }

            public static void BusquedaPrimeroElMejor()
            {
                var frontera = new SortedSet<Nodo>(new ComparadorPrimeroElMejor());
                HashSet<string> explorados = new HashSet<string>();
                frontera.Add(new Nodo(EstadoInicial, null, 0, CalcularHeuristica(EstadoInicial)));

                while (frontera.Count > 0)
                {
                    Nodo nodo = frontera.First();
                    frontera.Remove(nodo);

                    if (nodo.Estado == EstadoFinal)
                    {
                        ImprimirSolucion(nodo);
                        return;
                    }
                    explorados.Add(nodo.Estado);
                    foreach (string sucesor in GenerarSucesores(nodo.Estado))
                    {
                        int heuristica = CalcularHeuristica(sucesor);
                        if (!explorados.Contains(sucesor) && !frontera.Any(n => n.Estado == sucesor))
                        {
                            frontera.Add(new Nodo(sucesor, nodo, nodo.Costo + 1, heuristica));
                        }
                    }
                }
            }

            // === Funciones Auxiliares ===
            public static int CalcularHeuristica(string estado)
            {
                int distancia = 0;
                for (int i = 0; i < 9; i++)
                {
                    if (estado[i] != '0')
                    {
                        int valor = int.Parse(estado[i].ToString());
                        int filaActual = i / 3;
                        int colActual = i % 3;
                        int filaMeta = (valor - 1) / 3;  // Ej: "1" debe estar en (0,0)
                        int colMeta = (valor - 1) % 3;
                        distancia += Math.Abs(filaActual - filaMeta) + Math.Abs(colActual - colMeta);
                    }
                }
                return distancia;
            }

            public static List<string> GenerarSucesores(string estado)
            {
                List<string> sucesores = new List<string>();
                int posicionCero = estado.IndexOf('0');
                int[] movimientos = { -3, 3, -1, 1 };  // Arriba, abajo, izquierda, derecha

                foreach (int movimiento in movimientos)
                {
                    int nuevaPosicion = posicionCero + movimiento;
                    if (nuevaPosicion >= 0 && nuevaPosicion < 9 &&
                        !(posicionCero % 3 == 0 && movimiento == -1) &&  // Evitar borde izquierdo
                        !(posicionCero % 3 == 2 && movimiento == 1))     // Evitar borde derecho
                    {
                        char[] nuevoEstado = estado.ToCharArray();
                        nuevoEstado[posicionCero] = nuevoEstado[nuevaPosicion];
                        nuevoEstado[nuevaPosicion] = '0';
                        sucesores.Add(new string(nuevoEstado));
                    }
                }
                return sucesores;
            }

            public static void ImprimirSolucion(Nodo nodo)
            {
                Stack<string> solucion = new Stack<string>();
                while (nodo != null)
                {
                    solucion.Push(nodo.Estado);
                    nodo = nodo.Padre;
                }
                Console.WriteLine("\nSolución encontrada (pasos: " + (solucion.Count - 1) + "):");
                while (solucion.Count > 0)
                {
                    Console.WriteLine(solucion.Pop());
                }
            }

            // Comparadores para las colas prioritarias
            public class ComparadorAEstrella : IComparer<Nodo>
            {
                public int Compare(Nodo x, Nodo y) => x.CostoTotal.CompareTo(y.CostoTotal);
            }

            public class ComparadorPrimeroElMejor : IComparer<Nodo>
            {
                public int Compare(Nodo x, Nodo y) => x.Heuristica.CompareTo(y.Heuristica);
            }
        }
    }
}